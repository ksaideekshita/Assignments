﻿using System;

public class SubstringOccurrenceCounter
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a string:");
        string inputString = Console.ReadLine();

        Console.WriteLine("Enter the substring to search for:");
        string subString = Console.ReadLine();

        int count = 0;
        for (int i = 0; i < inputString.Length - subString.Length + 1; i++)
        {
            bool match = true;
            for (int j = 0; j < subString.Length; j++)
            {
                if (inputString[i + j] != subString[j])
                {
                    match = false;
                    break;
                }
            }

            if (match)
            {
                count++;
            }
        }

        Console.WriteLine("The number of occurrences of '{0}' in '{1}' is: {2}", subString, inputString, count);
        Console.ReadLine();
    }

}
