﻿using System;

public class PermutationGenerator
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of elements to store in the array (maximum 5 digits):");
        int n = Convert.ToInt32(Console.ReadLine());

        int[] arr = new int[n];
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine("Enter element {0}:", i);
            arr[i] = Convert.ToInt32(Console.ReadLine());
        }

        Console.WriteLine("The Permutations with a combination of {0} digits are:", n);
        permute(arr, 0, n - 1);
        Console.ReadLine();
    }

    private static void permute(int[] arr, int start, int end)
    {
        if (start == end)
        {
            for (int i = 0; i <= end; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }
        else
        {
            for (int i = start; i <= end; i++)
            {
                swap(arr, start, i);
                permute(arr, start + 1, end);
                swap(arr, start, i);
            }
        }
    }

    private static void swap(int[] arr, int a, int b)
    {
        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }
}
