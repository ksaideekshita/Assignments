﻿using System;

public class PrimeNumbersInRange
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the starting number of the range:");
        int start = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter the ending number of the range:");
        int end = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("The prime numbers between {0} and {1} are:", start, end);

        for (int num = start; num <= end; num++)
        {
            if (isPrime(num))
            {
                Console.Write(num + " ");
            }
        }
        Console.ReadLine();
        }

    public static bool isPrime(int num)
    {
        if (num <= 1) return false; 
        if (num <= 3) return true; 

       
        for (int i = 2; i <= Math.Sqrt(num); i += 2)
        {
            if (num % i == 0) return false;
        }

        return true;
    }
}
