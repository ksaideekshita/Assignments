﻿using System;
public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("enter a string");
        string inputString = Console.ReadLine();
        Console.WriteLine("enter n");
        int nthWord = int.Parse(Console.ReadLine());
        string result = GetNthWord(inputString, nthWord);
        if (result != null)
        {
            Console.WriteLine($"The {nthWord}th word is: {result}");
        }
        else
        {
            Console.WriteLine("there are no enough words");
        }
    }
    public static string GetNthWord(string str, int n)
    {
        string[] words = str.Split('#');
        if (n > words.Length || n < 1)
        {
            return null;

        }
        return words[n - 1];
    }
}