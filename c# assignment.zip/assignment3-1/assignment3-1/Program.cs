﻿using System;

public class VowelCounterSwitch
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a string:");
        string inputString = Console.ReadLine();

        int countA = 0, countE = 0, countI = 0, countO = 0, countU = 0;

        for (int i = 0; i < inputString.Length; i++)
        {
            char ch = Char.ToLower(inputString[i]);
            switch (ch)
            {
                case 'a':
                    countA++;
                    break;
                case 'e':
                    countE++;
                    break;
                case 'i':
                    countI++;
                    break;
                case 'o':
                    countO++;
                    break;
                case 'u':
                    countU++;
                    break;
            }
        }

        Console.WriteLine("Count of a: {0}", countA);
        Console.WriteLine("Count of e: {0}", countE);
        Console.WriteLine("Count of i: {0}", countI);
        Console.WriteLine("Count of o: {0}", countO);
        Console.WriteLine("Count of u: {0}", countU);
        Console.ReadLine();
    }
}
