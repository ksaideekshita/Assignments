﻿using System;

public class StringLength
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a string:");
        string inputString = Console.ReadLine();

        // Calculate the length using the String.Length property
        int stringLength = inputString.Length;

        Console.WriteLine("The length of the string '{0}' is: {1}", inputString, stringLength);
        Console.ReadLine();
    }
}
