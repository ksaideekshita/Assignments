﻿using System;

public class RightAngleTriangleNumbers
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of rows for the triangle:");
        int rows = Convert.ToInt32(Console.ReadLine());

        for (int i = 1; i <= rows; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(j);
            }
            Console.WriteLine(); 
            Console.ReadLine();
        }
    }
}
