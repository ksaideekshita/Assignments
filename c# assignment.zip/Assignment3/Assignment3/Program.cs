﻿using System;

public class IncrementFiveDigitNumber
{
    public static void Main(string[] args)
    {
        int number;

        
        do
        {
            Console.Write("Enter a five-digit number: ");
        } while (!int.TryParse(Console.ReadLine(), out number) || number.ToString().Length != 5);

        int newNumber = 0;
        int placeValue = 10000; 

        while (placeValue > 0)
        {
            int digit = number / placeValue;
            number %= placeValue; 

            
            newNumber += ((digit + 1) % 10) * placeValue;

            placeValue /= 10; 
        }

        Console.WriteLine("New number: {0}", newNumber);
        Console.ReadKey();
    }
}
