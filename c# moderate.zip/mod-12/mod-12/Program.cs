﻿using System;

public class ReverseCase
{
    public static string ReverseCharacterCase(string str)
    {
        char[] chars = str.ToCharArray(); 
        for (int i = 0; i < chars.Length; i++)
        {
            if (char.IsLetter(chars[i])) 
            {
                chars[i] = char.IsUpper(chars[i]) ? char.ToLower(chars[i]) : char.ToUpper(chars[i]);
            }
        }
        return new string(chars);
    }

    public static void Main(string[] args)
    {
        string inputString = "Hello, World!";
        string reversedCaseString = ReverseCharacterCase(inputString);

        Console.WriteLine("Original string: {0}", inputString);
        Console.WriteLine("String with reversed case: {0}", reversedCaseString);
        Console.ReadLine();
    }
}
