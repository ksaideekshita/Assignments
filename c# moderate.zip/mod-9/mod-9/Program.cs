﻿using System;

public class NumOfDigits
{
    public static int CountDigits(int number)
    {
        int count = 0;

        
        if (number < 0)
        {
            number = Math.Abs(number); 
        }

        
        while (number > 0)
        {
            number /= 10; 
            count++;
        }

        return count;
    }

    public static void Main(string[] args)
    {
        int[] testNumbers = { 1000, 12, -345 };

        foreach (int number in testNumbers)
        {
            int digitCount = CountDigits(number);
            Console.WriteLine("Number: {0}, Number of digits: {1}", number, digitCount);
        }
        Console.ReadLine();
    }
}
