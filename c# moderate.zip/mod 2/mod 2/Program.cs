﻿using System;

public class FindRepeatingNumber
{
    public static int FindRepeat(int[] arr)
    {
        int n = arr.Length;

        
        int slow = arr[0], fast = arr[0];
        do
        {
            slow = arr[slow];
            fast = arr[arr[fast]];
        } while (slow != fast);

        
        slow = arr[0];
        while (slow != fast)
        {
            slow = arr[slow];
            fast = arr[fast];
        }

        return slow;
    }

    public static void Main(string[] args)
    {
        int[] sequence = { 1, 2, 3, 3, 4, 5, 5, 6, 6, 7, 8, 9, 9 };
        int repeatedNumber = FindRepeat(sequence);

        Console.WriteLine("The repeating number is: {0}", repeatedNumber);
        Console.ReadLine();
    }
}
