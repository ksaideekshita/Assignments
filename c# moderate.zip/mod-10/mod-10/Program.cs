﻿using System;

public class InsertSubstring
{
    public static string InsertAfterFirst(string originalString, string searchString, string insertString)
    {
        int index = originalString.IndexOf(searchString);

        if (index != -1)
        {
           
            return originalString.Substring(0, index + searchString.Length) + insertString + originalString.Substring(index + searchString.Length);
        }
        else
        {
            
            return originalString;
        }
    }

    public static void Main(string[] args)
    {
        string originalString = "this is a string";
        string searchString = "a";
        string insertString = "test";

        string modifiedString = InsertAfterFirst(originalString, searchString, insertString);
        Console.WriteLine("The modified string is: \"{0}\"", modifiedString);
        Console.ReadLine();
    }
}
