﻿using System.Text;
using System;

public class CodeWords
{
    public static string CreateCodeWords(string userInput)
    {
        string alphabet = "abcdefghijklmnopqrstuvwxyz";

        StringBuilder codeWord = new StringBuilder();
        foreach (char c in userInput)
        {
            if (char.IsLetter(c))
            {
                int index = alphabet.IndexOf(char.ToLower(c));
                int newIndex = (index + 3) % 26;

                codeWord.Append(char.IsUpper(c) ? alphabet[newIndex].ToString().ToUpper() : alphabet[newIndex]);
            }
            else
            {
                codeWord.Append(c);
            }
        }

        return codeWord.ToString();
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a word to create a code word: ");
        string userInput = Console.ReadLine();

        string codeWord = CreateCodeWords(userInput);
        Console.WriteLine("Code word: {0}", codeWord);
    }
}
