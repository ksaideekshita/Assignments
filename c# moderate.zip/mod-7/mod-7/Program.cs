﻿using System.Collections.Generic;
using System;

public class RemoveRepeatedChars
{
    public static string Unrepeated(string word)
    {
        
        HashSet<char> uniqueChars = new HashSet<char>();
        string result = "";

        foreach (char c in word)
        {
            
            if (uniqueChars.Add(c))
            {
                result += c;
            }
        }

        return result;
    }

    public static void Main(string[] args)
    {
        string[] testWords = { "teshahset", "hello", "call 911" };

        foreach (string word in testWords)
        {
            string unrepeatedWord = Unrepeated(word);
            Console.WriteLine("Original word: {0}, Unrepeated: {1}", word, unrepeatedWord);
            Console.ReadLine();
        }
    }
}
