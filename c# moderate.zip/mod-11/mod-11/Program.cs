﻿using System;
using System.Text;

public class ReverseWords
{
    public static string ReverseSentence(string sentence)
    {
        string[] words = sentence.Trim().Split(' '); 

        
        Array.Reverse(words);

        
        StringBuilder reversedSentence = new StringBuilder();
        foreach (string word in words)
        {
            reversedSentence.Append(word + " ");
        }

        
        return reversedSentence.ToString().TrimEnd();
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a sentence: ");
        string inputSentence = Console.ReadLine();

        string reversedSentence = ReverseSentence(inputSentence);
        Console.WriteLine("Reversed sentence: {0}", reversedSentence);
        Console.ReadLine();

    }
}
