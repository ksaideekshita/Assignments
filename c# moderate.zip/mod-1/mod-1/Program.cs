﻿using System;

public class PrintX
{
    public static void Main(string[] args)
    {
        string message = "Hello World!";
        int messageLength = message.Length;

        for (int i = 0; i < messageLength; i++)
        {
            
            for (int j = 0; j < messageLength - i - 1; j++)
            {
                Console.Write(" ");
            }

            
            Console.Write(message[i] + "   ");

            
            for (int j = 0; j < 2 * (i - 1); j++)
            {
                Console.Write(" ");
            }

            
            if (i < messageLength - 1)
            {
                Console.Write(message[i] + "\n");
            }
        }

        
        for (int i = 0; i < messageLength; i++)
        {
            Console.Write(" ");
        }
        Console.WriteLine("!   !");
        Console.ReadLine();
    }
   
}
