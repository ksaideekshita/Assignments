﻿using System.Collections.Generic;
using System;

public class PrimeFactors
{
    public static List<int> FindPrimeFactors(int number)
    {
        List<int> factors = new List<int>();

        
        if (number == 1)
        {
            return factors;
        }

        
        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            
            while (number % i == 0)
            {
                factors.Add(i);
                number /= i;
            }
        }

        
        if (number > 2)
        {
            factors.Add(number);
        }

        return factors;
    }

    public static void Main(string[] args)
    {
        int[] testNumbers = { 14, 36, 45, 56 };

        foreach (int num in testNumbers)
        {
            List<int> primeFactors = FindPrimeFactors(num);
            Console.WriteLine("Prime factors of {0}:", num);
            string factorString = "";
            foreach (int factor in primeFactors)
            {
                factorString += factor + "x";
            }
            Console.WriteLine(factorString.Substring(0, factorString.Length - 1)); 
        }
        Console.ReadLine();
    }
}
