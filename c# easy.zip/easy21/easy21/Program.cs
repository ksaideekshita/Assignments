﻿
using System;
using System.Collections;



public class Calculator
{
    public static void Main(string[] args) {

         int Add(int a, int b)
        {
            return a + b;
        }

         double Add2(double a, double b)
        {
            return a + b;
        }

         string Add1(string a, string b)
        {
            return a + b;
        }
    }
}