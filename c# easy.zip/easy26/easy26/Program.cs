﻿using System;

public class CaseConverter
{
    public static string ConvertCase(string text)
    {
        char[] convertedChars = new char[text.Length];
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (char.IsLetter(c))
            {
                if (c >= 'A' && c <= 'Z')
                {
                    convertedChars[i] = (char)(c + 32); 
                }
                else if (c >= 'a' && c <= 'z')
                {
                    convertedChars[i] = (char)(c - 32); 
                }
            }
            else
            {
                convertedChars[i] = c;
            }
        }
        return new string(convertedChars);
    }

    public static void Main(string[] args)
    {
        string quote = "TiGer Is A LaRgE-HeArTeD GentlEmAN witH BounDleSS CouRAgE";
        string convertedQuote = ConvertCase(quote);

        Console.WriteLine("Original quote: {0}", quote);
        Console.WriteLine("Converted quote: {0}", convertedQuote);
        Console.ReadLine();
    }
}
