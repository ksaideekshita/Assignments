﻿using System;
using System.Collections;

public class ArrayListDemo
{
    public static void Main(string[] args)
    {
        ArrayList myList = new ArrayList();
        myList.Add("apple");
        myList.Add(10);
        myList.Add(true);

        
        myList.Remove("apple");
        myList.RemoveAt(1); 

        
        bool found = false;
        foreach (object item in myList)
        {
            if (item.Equals(true))
            {
                found = true;
                break;
            }
        }

        Console.WriteLine("Found 'true': " + found);

       
        myList[0] = "banana";

        
        Console.WriteLine("Modified ArrayList:");
        foreach (object item in myList)
        {
            Console.WriteLine(item);
        }
        Console.ReadLine();
    }
}
