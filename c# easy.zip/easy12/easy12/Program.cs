﻿using System;

public class AsteriskPyramid
{
    public static void Main(string[] args)
    {
        int rows = 4; 

        for (int i = 1; i <= rows; i++)
        {
            
            for (int j = 1; j <= rows - i; j++)
            {
                Console.Write(" ");
            }

            
            for (int j = 1; j <= 2 * i - 1; j++)
            {
                Console.Write("*");
            }

            
            Console.WriteLine();

        }
        Console.ReadLine();
    }
}
