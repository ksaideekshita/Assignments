﻿using System;
using System.Collections;

public class HashtableDemo
{
    public static void Main(string[] args)
    {
        
        Hashtable myTable = new Hashtable();
        myTable.Add("name", "John Doe");
        myTable.Add(1, "apple"); 
        
        myTable.Remove("name");

        
        if (myTable.ContainsKey(1))
        {
            Console.WriteLine("Value for key 1: " + myTable[1]);
        }

        
        myTable[1] = "banana";

        
        Console.WriteLine("Modified Hashtable:");
        foreach (DictionaryEntry entry in myTable)
        {
            Console.WriteLine("Key: {0}, Value: {1}", entry.Key, entry.Value);
        }
        Console.ReadLine();


    }
}
