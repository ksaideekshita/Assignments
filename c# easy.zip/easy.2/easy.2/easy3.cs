﻿using System;

public class ReverseString
{
    public static void Main(string[] args)
    {
        string message = "Hello World!!";

        // Iterate through the message in reverse order
        for (int i = message.Length - 1; i >= 0; i--)
        {
            Console.WriteLine(message[i]);
        }
    }
}
