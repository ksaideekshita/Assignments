﻿using System;

public class ReverseStringFunction
{
    public static string ReverseString(string str)
    {
        char[] charArray = str.ToCharArray(); 
        Array.Reverse(charArray); 
        return new string(charArray);
    }

    public static void Main(string[] args)
    {
        string originalString = "This is a string";
        string reversedString = ReverseString(originalString);

        Console.WriteLine("Original String: {0}", originalString);
        Console.WriteLine("Reversed String: {0}", reversedString);
        Console.ReadKey();
    }
}
