﻿using System;

public class MiddleCharacter
{
    public static string GetMiddleCharacter(string str)
    {
        int length = str.Length;

        if (length == 0)
        {
            return "Empty string"; 
        }

        int middleIndex = length / 2;
        return length % 2 == 0 ? str.Substring(middleIndex - 1, 2) : str[middleIndex].ToString();
    }

    public static void Main(string[] args)
    {
        string inputString = "JavaScript";
        string middleChar = GetMiddleCharacter(inputString);

        Console.WriteLine("Original string: {0}", inputString);
        Console.WriteLine("Middle character(s): {0}", middleChar);
        Console.ReadLine();
    }
}
