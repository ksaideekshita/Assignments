﻿using System;

public class TriangleNumberPattern
{
    public static void Main(string[] args)
    {
        int rows = 4; 

        for (int i = 1; i <= rows; i++)
        {
            
            for (int j = 1; j <= i; j++)
            {
                Console.Write(i);
            }

            
            Console.WriteLine();
        }
        Console.ReadLine();
    }
}
