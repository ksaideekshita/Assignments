﻿using System;
using System.Collections;

public class SortedListDemo
{
    public static void Main(string[] args)
    {
       
        SortedList myList = new SortedList();
        myList.Add(2, "apple");
        myList.Add(1, "banana");
        myList.Add(3, "cherry");

        myList.Remove("apple"); 

        
        int index = myList.IndexOfKey(2); 
        if (index >= 0)
        {
            Console.WriteLine("Value at index {0}: {1}", index, myList[index]);
        }

        
        myList[1] = "orange";

       
        Console.WriteLine("Modified SortedList:");
        foreach (DictionaryEntry entry in myList)
        {
            Console.WriteLine("Key: {0}, Value: {1}", entry.Key, entry.Value);
        }
    }
}
